import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  selectedLang = 'lang1';
  selectedUser = 'user1';
  toggleUserProfile: Boolean = true;
  toggleSearch: Boolean = true;
  toggleNotifications: Boolean = true;

  constructor() { }

  ngOnInit() {
  }

  showUserProfile() {
    this.toggleUserProfile = !this.toggleUserProfile;
  }

  showSearchBox() {
    this.toggleSearch = !this.toggleSearch;
  }

  showNotifications() {
    this.toggleNotifications = !this.toggleNotifications;
  }

}
